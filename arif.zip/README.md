# The Gingerbread Factory
Static site, no build step. To publish: push this folder to a GitHub repo, then Settings > Pages > deploy from the main branch (root).
